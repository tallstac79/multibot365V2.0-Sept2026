package com.bet365agent;

import android.accessibilityservice.AccessibilityService;
import android.graphics.Rect;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Read-only Accessibility PoC. Inspects the active UI tree.
 * Does NOT click, type, log in, or place bets.
 */
public class Bet365AccessibilityService extends AccessibilityService {
    private static final int MAX_NODES = 400;
    private static final int MAX_DUMP_CHARS = 12000;
    private static volatile Bet365AccessibilityService instance;

    public static boolean isRunning() {
        return instance != null;
    }

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        // Initial snapshot
        scanAndStore("onServiceConnected");
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;
        int type = event.getEventType();
        if (type != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                && type != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
                && type != AccessibilityEvent.TYPE_VIEW_SCROLLED) {
            return;
        }
        CharSequence pkgCs = event.getPackageName();
        String pkg = pkgCs == null ? "" : pkgCs.toString();
        // Focus on Chrome / Bet365-related packages; still scan others lightly for status
        if (pkg.contains("chrome") || pkg.contains("bet365") || pkg.contains("android.chrome")
                || type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            scanAndStore("event:" + type);
        }
    }

    @Override
    public void onInterrupt() {
        // no-op
    }

    @Override
    public void onDestroy() {
        instance = null;
        super.onDestroy();
    }

    /** Public trigger for MainActivity refresh button. */
    public static void requestScan() {
        Bet365AccessibilityService svc = instance;
        if (svc != null) {
            svc.scanAndStore("manual");
        }
    }

    private void scanAndStore(String reason) {
        try {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            String pkg = "";
            String title = "";
            if (root != null && root.getPackageName() != null) {
                pkg = root.getPackageName().toString();
            }
            // Window title if exposed
            List<AccessibilityWindowInfo> windows = getWindows();
            if (windows != null) {
                for (AccessibilityWindowInfo w : windows) {
                    if (w == null) continue;
                    if (w.getType() == AccessibilityWindowInfo.TYPE_APPLICATION) {
                        CharSequence t = w.getTitle();
                        if (t != null && t.length() > 0) {
                            title = t.toString();
                            break;
                        }
                    }
                }
            }

            StringBuilder dump = new StringBuilder();
            dump.append("reason=").append(reason).append('\n');
            dump.append("package=").append(pkg).append('\n');
            dump.append("title=").append(title).append('\n');
            dump.append("--- nodes ---\n");

            List<String> nodes = new ArrayList<>();
            if (root != null) {
                walk(root, 0, nodes);
                root.recycle();
            } else {
                dump.append("(no rootInActiveWindow)\n");
            }

            for (String line : nodes) {
                if (dump.length() + line.length() + 1 > MAX_DUMP_CHARS) {
                    dump.append("… truncated …\n");
                    break;
                }
                dump.append(line).append('\n');
            }

            ScanStore.saveScan(this, pkg, title, dump.toString(), System.currentTimeMillis());
        } catch (Exception e) {
            ScanStore.saveScan(this, "error", "", "scan failed: " + e, System.currentTimeMillis());
        }
    }

    private void walk(AccessibilityNodeInfo node, int depth, List<String> out) {
        if (node == null || out.size() >= MAX_NODES) return;

        CharSequence text = node.getText();
        CharSequence desc = node.getContentDescription();
        CharSequence cls = node.getClassName();
        CharSequence viewId = node.getViewIdResourceName();
        boolean clickable = node.isClickable();
        boolean editable = node.isEditable();
        boolean visible = node.isVisibleToUser();

        String textStr = text == null ? "" : text.toString().replace('\n', ' ').trim();
        String descStr = desc == null ? "" : desc.toString().replace('\n', ' ').trim();

        // Keep useful rows: has text/desc, or clickable, or depth shallow
        boolean interesting = (textStr.length() > 0) || (descStr.length() > 0) || clickable || depth <= 2;
        if (interesting && visible) {
            Rect bounds = new Rect();
            node.getBoundsInScreen(bounds);
            String line = String.format(Locale.US,
                    "d=%d click=%s edit=%s class=%s id=%s bounds=%s text=%s desc=%s",
                    depth,
                    clickable ? "Y" : "N",
                    editable ? "Y" : "N",
                    cls == null ? "?" : cls.toString(),
                    viewId == null ? "-" : viewId.toString(),
                    bounds.toShortString(),
                    truncate(textStr, 80),
                    truncate(descStr, 60)
            );
            out.add(line);
        }

        int childCount = node.getChildCount();
        for (int i = 0; i < childCount; i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                walk(child, depth + 1, out);
                child.recycle();
            }
            if (out.size() >= MAX_NODES) break;
        }
    }

    private static String truncate(String s, int max) {
        if (s == null) return "";
        if (s.length() <= max) return s;
        return s.substring(0, max) + "…";
    }
}
