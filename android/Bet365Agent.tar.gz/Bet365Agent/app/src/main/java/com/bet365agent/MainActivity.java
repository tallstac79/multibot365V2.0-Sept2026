package com.bet365agent;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.accessibility.AccessibilityManager;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.DateFormat;
import java.util.Date;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private TextView statusAccessibility;
    private TextView statusPackage;
    private TextView statusTimestamp;
    private TextView scanOutput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        statusAccessibility = findViewById(R.id.statusAccessibility);
        statusPackage = findViewById(R.id.statusPackage);
        statusTimestamp = findViewById(R.id.statusTimestamp);
        scanOutput = findViewById(R.id.scanOutput);

        Button openSettings = findViewById(R.id.btnOpenSettings);
        Button refresh = findViewById(R.id.btnRefresh);

        openSettings.setOnClickListener(v -> {
            Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        });

        refresh.setOnClickListener(v -> {
            Bet365AccessibilityService.requestScan();
            // small delay then refresh UI from prefs
            v.postDelayed(this::refreshUi, 400);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshUi();
    }

    private void refreshUi() {
        boolean enabled = isServiceEnabled();
        statusAccessibility.setText("Accessibility service enabled: " + (enabled ? "YES" : "NO"));

        String pkg = ScanStore.getPackage(this);
        String title = ScanStore.getTitle(this);
        statusPackage.setText("Foreground package: " + (pkg.isEmpty() ? "(none yet)" : pkg)
                + (title.isEmpty() ? "" : ("\nWindow title: " + title)));

        long ts = ScanStore.getTs(this);
        if (ts <= 0) {
            statusTimestamp.setText("Last scan: (none yet)");
        } else {
            statusTimestamp.setText("Last scan: " + DateFormat.getDateTimeInstance().format(new Date(ts)));
        }

        String dump = ScanStore.getDump(this);
        if (dump == null || dump.isEmpty()) {
            scanOutput.setText("No scan yet.\n\n1) Tap Open Accessibility settings\n2) Enable Bet365Agent Inspector\n3) Open Chrome with Bet365\n4) Return here and tap Refresh");
        } else {
            scanOutput.setText(dump);
        }
    }

    private boolean isServiceEnabled() {
        if (Bet365AccessibilityService.isRunning()) return true;
        AccessibilityManager am = (AccessibilityManager) getSystemService(Context.ACCESSIBILITY_SERVICE);
        if (am == null) return false;
        List<AccessibilityServiceInfo> enabled =
                am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK);
        if (enabled == null) return false;
        String myId = getPackageName() + "/.Bet365AccessibilityService";
        String myIdFull = getPackageName() + "/" + Bet365AccessibilityService.class.getName();
        for (AccessibilityServiceInfo info : enabled) {
            if (info == null || info.getId() == null) continue;
            String id = info.getId();
            if (id.equals(myId) || id.equals(myIdFull) || id.contains("Bet365AccessibilityService")) {
                return true;
            }
        }
        return false;
    }
}
