package com.bet365agent;

import android.content.Context;
import android.content.SharedPreferences;

/** Simple persistent store so the UI can show the last scan without adb/logcat. */
public final class ScanStore {
    private static final String PREFS = "bet365agent_poc";
    private static final String KEY_ENABLED = "service_enabled_hint";
    private static final String KEY_PACKAGE = "foreground_package";
    private static final String KEY_TITLE = "window_title";
    private static final String KEY_TS = "last_scan_ts";
    private static final String KEY_DUMP = "last_dump";

    private ScanStore() {}

    private static SharedPreferences prefs(Context ctx) {
        return ctx.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static void saveScan(Context ctx, String pkg, String title, String dump, long ts) {
        prefs(ctx).edit()
                .putString(KEY_PACKAGE, pkg == null ? "" : pkg)
                .putString(KEY_TITLE, title == null ? "" : title)
                .putString(KEY_DUMP, dump == null ? "" : dump)
                .putLong(KEY_TS, ts)
                .apply();
    }

    public static String getPackage(Context ctx) {
        return prefs(ctx).getString(KEY_PACKAGE, "");
    }

    public static String getTitle(Context ctx) {
        return prefs(ctx).getString(KEY_TITLE, "");
    }

    public static String getDump(Context ctx) {
        return prefs(ctx).getString(KEY_DUMP, "");
    }

    public static long getTs(Context ctx) {
        return prefs(ctx).getLong(KEY_TS, 0L);
    }
}
